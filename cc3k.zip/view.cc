#include "view.h"

View::View(int rowNum, int columnNum): rowNum(rowNum), columnNum(columnNum){}

View::~View(){}

