#include "controller.h"
#include <iostream>

int main(){
	Controller c;
	c.play();
}
