#include "game.h"
#include "player.h"
#include "shade.h"
#include "drow.h"
#include "vampire.h"
#include "troll.h"
#include "goblin.h"
#include "potion.h"
#include "ba.h"
#include "bd.h"
#include "wa.h"
#include "wd.h"
#include "dwarf.h"
#include "human.h"
#include "elf.h"
#include "orc.h"
#include "halfling.h"
#include "merchant.h"
//#include "dragon.h"

Game::Game(): theGrid(NULL), playerGold(0), notification(NULL), win(false), die(true), hostile(false) {}

void Game::setAllContent() {
    //first draw the 4 edges
    for (int i=0; i<rowNum; i++){
        (theGrid[i][0]).setContent("wall");
        (theGrid[i][columnNum-1]).setContent("wall");
    }
    for (int i=1; i<columnNum-1; i++){
        (theGrid[0][i]).setContent("wall");
        (theGrid[rowNum-1][i]).setContent("wall");
    }
    // fill the map with ' '
    for (int i=1; i<rowNum-1; i++) {
        for (int j=1; j<columnNum-1; j++){
            (theGrid[i][j]).setContent("empty");
        }
    }
    // draw the 5 chambers
    // draw the top-left chamber
    for (int i=2; i<8; i++) {
        (theGrid[i][2]).setContent("wall");
        (theGrid[i][29]).setContent("wall");
    }
    for (int j=3; j<29; j++) {
        (theGrid[2][j]).setContent("wall");
        (theGrid[7][j]).setContent("wall");
        for (int i=3; i<7; i++) {
            (theGrid[i][j]).setContent("floor tile");
        }
    }
    // draw the bottom-left chamber
    for (int i=14; i<23; i++) {
        (theGrid[i][3]).setContent("wall");
        (theGrid[i][25]).setContent("wall");
    }
    for (int j=4; j<25; j++) {
        (theGrid[14][j]).setContent("wall");
        (theGrid[22][j]).setContent("wall");
        for (int i=15; i<22; i++) {
            (theGrid[i][j]).setContent("floor tile");
        }
    }
    // draw the central chamber
    for (int i=9; i<14; i++) {
        (theGrid[i][37]).setContent("wall");
        (theGrid[i][50]).setContent("wall");
    }
    for (int j=38; j<50; j++) {
        (theGrid[9][j]).setContent("wall");
        (theGrid[13][j]).setContent("wall");
        for (int i=10; i<13; i++) {
            (theGrid[i][j]).setContent("floor tile");
        }
    }
    // draw the bottom-right chamber
    for (int i=15; i<23; i++) {(theGrid[i][76]).setContent("wall");}
    for (int i=15; i<19; i++) {(theGrid[i][64]).setContent("wall");}
    for (int i=18; i<23; i++) {(theGrid[i][36]).setContent("wall");}
    for (int j=65; j<76; j++) {(theGrid[15][j]).setContent("wall");}
    for (int j=37; j<76; j++) {(theGrid[22][j]).setContent("wall");}
    for (int j=37; j<64; j++) {(theGrid[18][j]).setContent("wall");}
    for (int j=65; j<76; j++) {
        for (int i=16; i<22; i++) {
            (theGrid[i][j]).setContent("floor tile");
        }
    }
    for (int j=37; j<65; j++) {
        for (int i=19; i<22; i++) {
            (theGrid[i][j]).setContent("floor tile");
        }
    }
    
    // draw the top-right chamber
    
    
    for (int i=39; i<62; i++){
        (theGrid[2][i]).setContent("wall");
        for (int j=3; j<7; j++) {
            (theGrid[j][i]).setContent("floor tile");
        }
    }
    for (int j=2; j<8; j++) {(theGrid[j][38]).setContent("wall");}
    for (int j=2; j<5; j++) {(theGrid[j][62]).setContent("wall");}
    for (int i=63; i<70; i++){(theGrid[4][i]).setContent("wall");}
    for (int j=4; j<6; j++) {(theGrid[j][70]).setContent("wall");}
    for (int i=71; i<73; i++){(theGrid[5][i]).setContent("wall");}
    for (int j=5; j<7; j++) {(theGrid[j][73]).setContent("wall");}
    for (int i=74; i<76; i++){(theGrid[6][i]).setContent("wall");}
    for (int j=6; j<14; j++) {(theGrid[j][76]).setContent("wall");}
    for (int j=7; j<14; j++) {(theGrid[j][60]).setContent("wall");}
    for (int i=39; i<60; i++){(theGrid[7][i]).setContent("wall");}
    for (int i=61; i<76; i++){(theGrid[13][i]).setContent("wall");}
    for (int i=62; i<70; i++){(theGrid[5][i]).setContent("floor tile");}
    for (int i=62; i<73; i++){(theGrid[6][i]).setContent("floor tile");}
    for (int i=61; i<76; i++) {
        for (int j=7; j<13; j++) {
            (theGrid[j][i]).setContent("floor tile");
        }
    }
    // draw the horizontal passages
    for (int i=30; i<38; i++) {(theGrid[4][i]).setContent("passage");}
    for (int i=31; i<44; i++) {(theGrid[8][i]).setContent("passage");}
    for (int i=13; i<32; i++) {(theGrid[11][i]).setContent("passage");}
    for (int i=54; i<60; i++) {(theGrid[11][i]).setContent("passage");}
    for (int i=31; i<55; i++) {(theGrid[16][i]).setContent("passage");}
    for (int i=26; i<36; i++) {(theGrid[20][i]).setContent("passage");}
    // draw the vertical passages
    for (int j=8; j<14; j++) {(theGrid[j][13]).setContent("passage");}
    for (int j=8; j<21; j++) {(theGrid[j][31]).setContent("passage");}
    for (int j=4; j<9; j++) {(theGrid[j][33]).setContent("passage");}
    for (int j=14; j<18; j++) {(theGrid[j][43]).setContent("passage");}
    for (int j=11; j<17; j++) {(theGrid[j][54]).setContent("passage");}
    (theGrid[14][69]).setContent("passage");
    // draw the doors
    (theGrid[4][29]).setContent("doorway");
    (theGrid[4][38]).setContent("doorway");
    (theGrid[7][13]).setContent("doorway");
    (theGrid[7][43]).setContent("doorway");
    (theGrid[9][43]).setContent("doorway");
    (theGrid[11][60]).setContent("doorway");
    (theGrid[13][43]).setContent("doorway");
    (theGrid[13][69]).setContent("doorway");
    (theGrid[14][13]).setContent("doorway");
    (theGrid[15][69]).setContent("doorway");
    (theGrid[18][43]).setContent("doorway");
    (theGrid[20][25]).setContent("doorway");
    (theGrid[20][36]).setContent("doorway");
    
    //set all prev equal to the original content of the cell
    for (int i=0; i<25; i++) {
        for (int j=0; j<79; j++) {
            theGrid[i][j].setOrigin(theGrid[i][j].getContent());
        }
    }
}

void Game::init(int row, int column, GameNotification *gameNotification){
    if (theGrid) clearGame();
    rowNum = row;
    columnNum = column;
    win = false;
    die = false;
    notification = gameNotification;
    theGrid = new Cell*[rowNum];
    for (int i=0; i<rowNum; ++i) {
        theGrid[i] = new Cell[columnNum];
    }
    for (int i=0; i<rowNum; ++i) {
        for (int j=0; j<columnNum;++j) {
            (theGrid[i][j]).setGame(this);
            (theGrid[i][j]).setCoords(i, j);
        }
    }
    for (int i=0; i<rowNum; ++i) {
        for (int j=0; j<columnNum;++j) {
            if (i != 0 && j != 0) (theGrid[i][j]).addNeighbour(&(theGrid[i-1][j-1]), 0);
            if (i != 0) (theGrid[i][j]).addNeighbour(&(theGrid[i-1][j]), 1);
            if (i != 0 && j != column-1) (theGrid[i][j]).addNeighbour(&(theGrid[i-1][j+1]), 2);
            if (j != 0) (theGrid[i][j]).addNeighbour(&(theGrid[i][j-1]), 3);
            if (j != column-1) (theGrid[i][j]).addNeighbour(&(theGrid[i][j+1]), 4);
            if (i != row-1 && j != 0) (theGrid[i][j]).addNeighbour(&(theGrid[i+1][j-1]), 5);
            if (i != row-1) (theGrid[i][j]).addNeighbour(&(theGrid[i+1][j]), 6);
            if (i != row-1 && j != column-1)(theGrid[i][j]).addNeighbour(&(theGrid[i+1][j+1]), 7);
        }
    }
    setAllContent();
}

void Game::notifyHP(int change) {
    notification->notifyHP(change);
}

void Game::notifyGold(int change) {
    notification->notifyGold(change);
}

void Game::setPlayerHP(int change) {
    playerHP = change;
    notifyHP(change);
}

void Game::setPlayerGold(int change) {
    playerGold = change;
    setPoint(change);
    notifyGold(change);
}

void Game::setDie(bool change){
	die = change;
}

void Game::setPoint(int change) {
    point = change;
}

int Game::getPlayerHP() const{
    return playerHP;
}

int Game::getPlayerGold() const{
    return playerGold;
}

int Game::getPoint() const{
    return point;
}

bool Game::getDie() const{
	return die;
}

void Game::notify(int row, int column, char ch) {
    notification->notify(row, column, ch);
}

void Game::addGold(Cell *gp, const std::string &type) {
    gp->setContent("gold");
    gp->setType(type);
    notify(gp->getRow(), gp->getColumn(), 'G');
    /*Cell *x;
    if (type == "dragon hoard") {
        int tileNeighbour = 0;
        for (int i=0;i<9;i++) {
            x = gp->getNeighbour(i);
            if (x->getContent() == "floor tile") {
                tileNeighbour += 1;
            }
        }
        int g = rand()%tileNeighbour;
        int j = 0;
        for (int i=0;i<9;i++) {
            x = gp->getNeighbour(i);
            if (j == g && x->getContent() == "floor tile") {
                break;
            }
            if (j < g && x->getContent() == "floor tile") {
                j += 1;
            }
        }
        addEnemy(x, "dragon");
    }*/
}

void Game::addPotion(Cell *pp, const std::string &type) {
    pp->setContent("unknown potion");
    pp->setType(type);
    notify(pp->getRow(), pp->getColumn(),'P');
}

void Game::addEnemy(Cell *ep, const std::string &type){
    ep->setContent("enemy");
    ep->setType(type);
    if (type == "dwarf") {
        Enemy *e = new Dwarf(ep, this);
        ep->setCharacter(e);
        notify(ep->getRow(), ep->getColumn(), 'W');
    } else if (type == "human") {
        Enemy *e = new Human(ep, this);
        ep->setCharacter(e);
        notify(ep->getRow(), ep->getColumn(), 'H');
    } else if (type == "elf") {
        Enemy *e = new Elf(ep, this);
        ep->setCharacter(e);
        notify(ep->getRow(), ep->getColumn(), 'E');
    } else if (type == "orc") {
        Enemy *e = new Orc(ep, this);
        ep->setCharacter(e);
        notify(ep->getRow(), ep->getColumn(), 'O');
    } else if (type == "halfling") {
        Enemy *e = new Halfling(ep, this);
        ep->setCharacter(e);
        notify(ep->getRow(), ep->getColumn(), 'L');
    } else if (type == "merchant") {
        Enemy *e = new Merchant(ep, this);
        ep->setCharacter(e);
        notify(ep->getRow(), ep->getColumn(), 'M');
    } /*else if (type == "dragon") {
        Enemy *e = new Dragon(ep, this);
        ep->setCharacter(e);
        notify(ep->getRow(), ep->getColumn(), 'D');
    } */else {}
}

void Game::clearGame(){
    if (theGrid) {
        for (int i=0; i<rowNum; ++i) {
            if (theGrid[i]){
		for (int j=0; j<columnNum; ++j) {
			(theGrid[i][j]).eraseChar();
		}
                delete[] theGrid[i];
                theGrid[i] = NULL;
            }
        }
        delete[] theGrid;
        theGrid = NULL;
    }
    p = NULL;
    win = false;
}

void Game::notifyAction(const std::string &change) {
    notification->notifyAction(change);
}

void Game::createPC(const std::string &race){
    int chamber = rand()%5;
    Cell *pl = randomGenerateCell(chamber);
    if (race == "shade") {
        p = new Shade(pl, this);
        playerHP = 125;
    } else if (race == "drow") {
        p = new Drow(pl, this);
        playerHP = 150;
    } else if (race == "vampire") {
        p = new Vampire(pl, this);
        playerHP = 50;
    } else if (race == "troll") {
        p = new Troll(pl, this);
        playerHP = 120;
    } else if (race == "goblin") {
        p = new Goblin(pl, this);
        playerHP = 110;
    } else {}
    notify(pl->getRow(), pl->getColumn(), '@');
    pl->setContent("player");
    pl->setType(race);
    pl->setCharacter(p);
    notifyAction("Player character has spawned. ");
    int g = rand()%5;
    while (g == chamber) {
        g= rand()%5;
    }
    Cell *sp = randomGenerateCell(g);
    sp->setContent("stairs");
    notify(sp->getRow(), sp->getColumn(), '\\');
}

Game::~Game(){
    clearGame();
    notification = NULL;
}

bool Game::move(const std::string &m){
    return p->move(m);
}

bool Game::usePotion(const std::string &d){
    return p->usePotion(d);
}

bool Game::isWon() const{
	return win;
}

void Game::knowPotion(const std::string &p){
	for (int i=0; i<rowNum; i++){
		for (int j=0; j<columnNum; j++){
			if ((theGrid[i][j]).getType() == p) (theGrid[i][j]).setContent("potion");
		}
	}
}

void Game::useTempPotion(const std::string &p){
    if (p == "BA") {
        this->p = new BA((this->p)->getCell(), this, *(this->p));
        notifyAtk((this->p)->getAtk());
    } else if (p == "BD") {
        this->p = new BD((this->p)->getCell(), this, *(this->p));
        notifyDef((this->p)->getDef());
    } else if (p == "WA") {
        this->p = new WA((this->p)->getCell(), this, *(this->p));
        notifyAtk((this->p)->getAtk());
    } else if (p == "WD") {
        this->p = new WD((this->p)->getCell(), this, *(this->p));
        notifyDef((this->p)->getDef());
    } else { std::cout << "invalid potion" << std::endl; }
}

void Game::notifyAtk(double change){
	notification->notifyAtk(change);
}

void Game::notifyDef(double change){
        notification->notifyDef(change);
}

void Game::enemiesAct(){
	for (int i=0; i<rowNum; i++) {
        for (int j=0; j<columnNum; j++) {
			if ((theGrid[i][j]).getContent() == "enemy") {
				(theGrid[i][j]).refreshEnemy();
			}
		}
	}
	for (int i=0; i<rowNum; i++) {
		for (int j=0; j<columnNum; j++) {
	//		std::cout << i << " " << j << std::endl;
			if ((theGrid[i][j]).getContent() == "enemy") {
				(theGrid[i][j]).enemyAct();
			}
		}
	}
}

Player *Game::getPlayer(){
	return p;
}

bool Game::attack(const std::string &d) {
    return p->attack(d, p->getAtk());
}

Cell * Game::randomGenerateCell(int chamber) {
    Cell *temp;
    int t = validTile(chamber);
    int valid = rand()%t;
    int pos = 0;
    if (chamber == 0) { //top-left chamber
        for (int i=3; i<7; i++) {
            for (int j=3; j<29; j++) {
                temp = &(theGrid[i][j]);
                if (pos == valid && temp->getContent()=="floor tile") {break;}
                if (pos < valid && temp->getContent()=="floor tile") {pos += 1;}
            }
        }
    } else if (chamber == 1) { //bottom-left chamber
        for (int i=15; i<22; i++) {
            for (int j=4; j<25; j++) {
                temp = &(theGrid[i][j]);
                if (pos == valid && temp->getContent()=="floor tile") {break;}
                if (pos < valid && temp->getContent()=="floor tile") {pos += 1;}
            }
        }
    } else if (chamber == 2) { //central chamber
        for (int i=10; i<13; i++) {
            for (int j=38; j<50; j++) {
                temp = &(theGrid[i][j]);
                if (pos == valid && temp->getContent()=="floor tile") {break;}
                if (pos < valid && temp->getContent()=="floor tile") {pos += 1;}
            }
        }
    } else if (chamber == 3) { //bottom-right chamber
        for (int i=16; i<22; i++) {
            for (int j=65; j<76; j++) {
                temp = &(theGrid[i][j]);
                if (pos == valid && temp->getContent()=="floor tile") {break;}
                if (pos < valid && temp->getContent()=="floor tile") {pos += 1;}
            }
        }
        if (pos < valid) {
            for (int i=19; i<22; i++) {
                for (int j=37; j<65; j++) {
                    temp = &(theGrid[i][j]);
                    if (pos == valid && temp->getContent()=="floor tile") {
                        break;
                    }
                    if (temp->getContent()=="floor tile") {
                        pos += 1;
                    }
                }
            }
        }
    } else { //top-right chamber
        for (int i=3; i<7; i++) {
            for (int j=39; j<62; j++) {
                temp = &(theGrid[i][j]);
                if (pos == valid && temp->getContent()=="floor tile") {break;}
                if (temp->getContent()=="floor tile") {pos += 1;}
            }
        }
        if (pos < valid) {
            for (int i=62; i<70; i++){
                temp = &(theGrid[5][i]);
                if (pos == valid && temp->getContent()=="floor tile") {break;}
                if (temp->getContent()=="floor tile") {pos += 1;}
            }
        }
        if (pos < valid) {
            for (int i=62; i<73; i++){
                temp = &(theGrid[6][i]);
                if (pos == valid && temp->getContent()=="floor tile") {break;}
                if (temp->getContent()=="floor tile") {pos += 1;}
            }
        }
        if (pos < valid) {
            for (int i=7; i<13; i++) {
                for (int j=61; j<76; j++) {
                    temp = &(theGrid[i][j]);
                    if (pos == valid && temp->getContent()=="floor tile") {break;}
                    if (temp->getContent()=="floor tile") {pos += 1;}
                }
            }
        }
    }
    return temp;
}

int Game::validTile(int chamber) {
    int valid = 0;
    Cell *temp;
    if (chamber == 0) { //top-left chamber
        for (int i=3; i<7; i++) {
            for (int j=3; j<29; j++) {
                temp = &(theGrid[i][j]);
                if (temp->getContent()=="floor tile") {valid += 1;}
            }
        }
    } else if (chamber == 1) { //bottom-left chamber
        for (int i=15; i<22; i++) {
            for (int j=4; j<25; j++) {
                temp = &(theGrid[i][j]);
                if (temp->getContent()=="floor tile") {valid += 1;}
            }
        }
    } else if (chamber == 2) { //central chamber
        for (int i=10; i<13; i++) {
            for (int j=38; j<50; j++) {
                temp = &(theGrid[i][j]);
                if (temp->getContent()=="floor tile") {valid += 1;}
            }
        }
    } else if (chamber == 3) { //bottom-right chamber
        for (int i=16; i<22; i++) {
            for (int j=65; j<76; j++) {
                temp = &(theGrid[i][j]);
                if (temp->getContent()=="floor tile") {valid += 1;}
            }
        }
        for (int i=19; i<22; i++) {
            for (int j=37; j<65; j++) {
                temp = &(theGrid[i][j]);
                if (temp->getContent()=="floor tile") {valid += 1;}
            }
        }
    } else if (chamber == 4) { //top-right chamber
        for (int i=3; i<7; i++) {
            for (int j=39; j<62; j++) {
                temp = &(theGrid[i][j]);
                if (temp->getContent()=="floor tile") {valid += 1;}
            }
        }
        for (int i=62; i<70; i++){
            temp = &(theGrid[5][i]);
            if (temp->getContent()=="floor tile") {valid += 1;}
        }
        for (int i=62; i<73; i++){
            temp = &(theGrid[6][i]);
            if (temp->getContent()=="floor tile") {valid += 1;}
        }
        for (int i=7; i<13; i++) {
            for (int j=61; j<76; j++) {
                temp = &(theGrid[i][j]);
                if (temp->getContent()=="floor tile") {valid += 1;}
            }
        }
    } else { valid = 0; }
    return valid;
}

std::string Game::generateEnemy() {
    int e = rand()%18;
    std::string enemy;
    if ( e >= 0 && e < 4) {
        enemy = "human";
    } else if ( e >= 4 && e < 7) {
        enemy = "dwarf";
    } else if ( e >= 7 && e < 12) {
        enemy = "halfling";
    } else if ( e >= 12 && e < 14) {
        enemy = "elf";
    } else if ( e >= 14 && e < 16) {
        enemy = "orc";
    } else if ( e >= 16 && e < 18) {
        enemy = "merchant";
    } else { enemy = ""; }
    return enemy;
}

std::string Game::generateGold() {
    int g = rand()%7;
    std::string goldType;
    if ( g >= 0 && g < 5) {
        goldType = "normal";
    } else if ( g >= 5 && g < 7) {
        goldType = "small";
    } /*else if ( g == 7 ) {
        goldType = "dragon hoard";
    } */else { goldType = ""; }
    return goldType;
}

std::string Game::generatePotion() {
    int p = rand()%6;
    std::string potion;
    if (p == 0) {
        potion = "RH";
    } else if (p == 1) {
        potion = "PH";
    } else if (p == 2) {
        potion = "BA";
    } else if (p == 3) {
        potion = "WA";
    } else if (p == 4) {
        potion = "BD";
    } else if (p == 5) {
        potion = "WD";
    } else { potion = ""; }
    return potion;
}

void Game::generateAll() {
    for (int i=0;i<10;i++) {
        addPotion(randomGenerateCell(rand()%5), generatePotion());
    }
    for (int i=0;i<10;i++) {
        addGold(randomGenerateCell(rand()%5), generateGold());
    }
    for (int i=0;i<20;i++) {
        addEnemy(randomGenerateCell(rand()%5), generateEnemy());
    }
}

bool Game::getHostile() const {
    return hostile;
}

void Game::setHostile(bool change) {
    hostile = change;
}
